
		var createdTime=Date.now(); var clickedTime; var reactionTime;var averageTime=0;var count=0;
	
		document.getElementById("squarebox").onclick=function(){
			count++;
			clickedTime=Date.now();
			reactionTime=(clickedTime-createdTime)/1000;
			averageTime=(averageTime+reactionTime)/count;
			document.getElementById("squarebox").style.display="none";
			squareBlock();
			document.getElementById("timedisplay").innerHTML=reactionTime;
			document.getElementById("averagetimedisplay").innerHTML=averageTime;
		}
		
		function getRandomColor() {
			var letters = '0123456789ABCDEF'.split('');
			var color = '#';
			for (var i = 0; i < 6; i++) {
			color += letters[Math.floor(Math.random() * 16)];
			}
			return color;
		}
	
		
		function squareBlock(){
		
			var x=Math.random();
			console.log(x);
			x =x*1000;
			console.log(x);
		
			setTimeout(function(){
				
				var shape=Math.random();
				if(shape>0.5){
					document.getElementById("squarebox").style.borderRadius="100px";
				}
				else{
					document.getElementById("squarebox").style.borderRadius="0";
				}
				
				var top=Math.random();
				top=top*350;
				var left=Math.random();
				left=left*250;
				
				document.getElementById("squarebox").style.top=top+"px";
				document.getElementById("squarebox").style.left=left+"px";
				
				document.getElementById("squarebox").style.backgroundColor=getRandomColor();
				document.getElementById("squarebox").style.display="block";
				
				createdTime=Date.now();
		
			},x);
		
		}